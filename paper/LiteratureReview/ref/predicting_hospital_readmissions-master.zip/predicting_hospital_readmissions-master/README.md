# predicting_hospital_readmissions
This repo contains the final version of my project to predict hospital readmission in diabetic patients. The repo contains all data input files and Jupyter notebooks files. 
